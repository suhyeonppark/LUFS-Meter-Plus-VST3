LUFS Meter Plus 1.0.0

Universal macOS VST3 (arm64 + x86_64), minimum macOS 11.0.

Manual install:
  Copy "LUFS Meter Plus.vst3" to:
  ~/Library/Audio/Plug-Ins/VST3/

System-wide install:
  Copy "LUFS Meter Plus.vst3" to:
  /Library/Audio/Plug-Ins/VST3/
